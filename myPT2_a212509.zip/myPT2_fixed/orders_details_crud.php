<?php
 
include_once 'database.php';
 
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 
//Create
if (isset($_POST['addproduct'])) {
 
  try {
 
    $stmt = $conn->prepare("INSERT INTO tbl_orders_details_a212509(fld_order_detail_num,
      fld_order_num, fld_product_num, fld_order_detail_quantity)
      VALUES(:odid, :oid, :pid, :quantity)");
   
    $stmt->bindParam(':odid', $odid, PDO::PARAM_STR);
    $stmt->bindParam(':oid', $oid, PDO::PARAM_STR);
    $stmt->bindParam(':pid', $pid, PDO::PARAM_STR);
    $stmt->bindParam(':quantity', $quantity, PDO::PARAM_STR);
       
    $odid = uniqid('D', true);
    $oid = $_POST['oid'];
    $pid = $_POST['pid'];
    $quantity = $_POST['quantity'];
     
    $stmt->execute();
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}
 
//Delete
if (isset($_GET['delete'])) {
 
  try {
 
    $stmt = $conn->prepare("DELETE FROM tbl_orders_details_a212509 WHERE fld_order_detail_num = :odid");
   
    $stmt->bindParam(':odid', $odid, PDO::PARAM_STR);
       
    $odid = $_GET['delete'];
     
    $stmt->execute();

    $oid = $_GET['oid'];
    header("Location: orders_details.php?oid=$oid");
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}
 
  $conn = null;
 
?>

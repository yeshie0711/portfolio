<!DOCTYPE html>
<html>
<head>
    <title>Fitness Machine Ordering System</title>
</head>

<body>

<h1>Fitness Machine Ordering System</h1>

<hr>

<a href="index.php">Home</a> |
<a href="products.php">Products</a> |
<a href="customers.php">Customers</a> |
<a href="staffs.php">Staffs</a> |
<a href="orders.php">Orders</a>

<hr>

<h2>Welcome to the Fitness Machine Ordering System</h2>
<p>Please choose a menu above.</p>

</body>
</html>

<?php
  include_once 'orders_crud.php';
?>

<!DOCTYPE html>
<html>
<head>
  <title>Fitness Machine Ordering System : Orders</title>
</head>
<body>
  <center>
    <a href="index.php">Home</a> |
    <a href="products.php">Products</a> |
    <a href="customers.php">Customers</a> |
    <a href="staffs.php">Staffs</a> |
    <a href="orders.php">Orders</a>
     <hr>
    <form action="orders.php" method="post">
      Order ID
      <input name="oid" type="text" readonly value="<?php if(isset($_GET['edit'])) echo $editrow['fld_order_num']; ?>"> <br>
      Order Date
      <input name="orderdate" type="text" readonly value="<?php if(isset($_GET['edit'])) echo $editrow['fld_order_date']; ?>"> <br>
      Staff
      <select name="sid">
      <?php
        try {
          $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
          $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
          $stmt = $conn->prepare("SELECT * FROM tbl_staffs_a212509_pt2");
          $stmt->execute();
          $staffs = $stmt->fetchAll();
        } catch(PDOException $e) {
          echo "Error: " . $e->getMessage();
        }
        foreach($staffs as $staff) {
          $selected = (isset($_GET['edit']) && $editrow['fld_staff_num'] == $staff['fld_staff_num']) ? "selected" : "";
          echo "<option value=\"{$staff['fld_staff_num']}\" $selected>{$staff['fld_staff_fname']} {$staff['fld_staff_lname']}</option>";
        }
        $conn = null;
        ?>
      </select> <br>
      Customer
      <select name="cid">
        <?php
        try {
          $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
          $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
          $stmt = $conn->prepare("SELECT * FROM tbl_customers_a212509_pt2");
          $stmt->execute();
          $customers = $stmt->fetchAll();
        } catch(PDOException $e) {
          echo "Error: " . $e->getMessage();
        }
        foreach($customers as $customer) {
          $selected = (isset($_GET['edit']) && $editrow['fld_customer_num'] == $customer['fld_customer_num']) ? "selected" : "";
          echo "<option value=\"{$customer['fld_customer_num']}\" $selected>{$customer['fld_customer_fname']} {$customer['fld_customer_lname']}</option>";
        }
        $conn = null;
        ?>
      </select> <br>
      <?php if (isset($_GET['edit'])) { ?>
      <input type="hidden" name="oid" value="<?php echo $editrow['fld_order_num']; ?>">
      <button type="submit" name="update">Update</button>
      <?php } else { ?>
      <button type="submit" name="create">Create</button>
      <?php } ?>
      <button type="reset">Clear</button>
    </form>
    <hr>
    <table border="1">
      <tr>
        <td>Order ID</td>
        <td>Order Date</td>
        <td>Staff</td>
        <td>Customer</td>
        <td></td>
      </tr>
      <?php
      // Read
      try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT tbl_orders_a212509.*, 
          CONCAT(tbl_staffs_a212509_pt2.fld_staff_fname, ' ', tbl_staffs_a212509_pt2.fld_staff_lname) AS staff_name,
          CONCAT(tbl_customers_a212509_pt2.fld_customer_fname, ' ', tbl_customers_a212509_pt2.fld_customer_lname) AS customer_name
          FROM tbl_orders_a212509
          LEFT JOIN tbl_staffs_a212509_pt2 ON tbl_orders_a212509.fld_staff_num = tbl_staffs_a212509_pt2.fld_staff_num
          LEFT JOIN tbl_customers_a212509_pt2 ON tbl_orders_a212509.fld_customer_num = tbl_customers_a212509_pt2.fld_customer_num");
        $stmt->execute();
        $result = $stmt->fetchAll();
      }
      catch(PDOException $e){
            echo "Error: " . $e->getMessage();
      }
      foreach($result as $readrow) {
      ?>
      <tr>
        <td><?php echo $readrow['fld_order_num']; ?></td>
        <td><?php echo $readrow['fld_order_date']; ?></td>
        <td><?php echo $readrow['staff_name']; ?></td>
        <td><?php echo $readrow['customer_name']; ?></td>
        <td>
          <a href="orders_details.php?oid=<?php echo $readrow['fld_order_num']; ?>">Details</a>
          <a href="orders.php?edit=<?php echo $readrow['fld_order_num']; ?>">Edit</a>
          <a href="orders.php?delete=<?php echo $readrow['fld_order_num']; ?>" onclick="return confirm('Are you sure to delete?');">Delete</a>
        </td>
      </tr>
      <?php
      }
      $conn = null;
      ?>
    </table>
  </center>
</body>
</html>

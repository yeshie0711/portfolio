<?php
  include_once 'products_crud.php';
?>
 
<!DOCTYPE html>
<html>
<head>
  <title>Fitness Machine Ordering System : Products</title>
</head>
<body>
  <center>
    <a href="index.php">Home</a> |
    <a href="products.php">Products</a> |
    <a href="customers.php">Customers</a> |
    <a href="staffs.php">Staffs</a> |
    <a href="orders.php">Orders</a>
    <hr>
    <form action="products.php" method="post">
      Product ID
      <input name="pid" type="text" value="<?php if(isset($_GET['edit'])) echo $editrow['fld_product_num']; ?>"> <br>
      Name
      <input name="name" type="text" value="<?php if(isset($_GET['edit'])) echo $editrow['fld_product_name']; ?>"> <br>
      Price (RM)
      <input name="price" type="text" value="<?php if(isset($_GET['edit'])) echo $editrow['fld_product_price']; ?>"> <br>
      Brand
      <select name="brand">
        <option value="TRAX" <?php if(isset($_GET['edit'])) if($editrow['fld_product_brand']=="TRAX") echo "selected"; ?>>TRAX</option>
        <option value="Vigor Fitness" <?php if(isset($_GET['edit'])) if($editrow['fld_product_brand']=="Vigor Fitness") echo "selected"; ?>>Vigor Fitness</option>
        <option value="MY-HI" <?php if(isset($_GET['edit'])) if($editrow['fld_product_brand']=="MY-HI") echo "selected"; ?>>MY-HI</option>
        <option value="KingSmith" <?php if(isset($_GET['edit'])) if($editrow['fld_product_brand']=="KingSmith") echo "selected"; ?>>KingSmith</option>
        <option value="Chia Sports" <?php if(isset($_GET['edit'])) if($editrow['fld_product_brand']=="Chia Sports") echo "selected"; ?>>Chia Sports</option>
        <option value="Ultra Sports" <?php if(isset($_GET['edit'])) if($editrow['fld_product_brand']=="Ultra Sports") echo "selected"; ?>>Ultra Sports</option>
        <option value="BodySolid" <?php if(isset($_GET['edit'])) if($editrow['fld_product_brand']=="BodySolid") echo "selected"; ?>>BodySolid</option>
        <option value="Rogue Fitness" <?php if(isset($_GET['edit'])) if($editrow['fld_product_brand']=="Rogue Fitness") echo "selected"; ?>>Rogue Fitness</option>
        <option value="Life Fitness" <?php if(isset($_GET['edit'])) if($editrow['fld_product_brand']=="Life Fitness") echo "selected"; ?>>Life Fitness</option>
        <option value="Technogym" <?php if(isset($_GET['edit'])) if($editrow['fld_product_brand']=="Technogym") echo "selected"; ?>>Technogym</option>
        <option value="Matrix Fitness" <?php if(isset($_GET['edit'])) if($editrow['fld_product_brand']=="Matrix Fitness") echo "selected"; ?>>Matrix Fitness</option>
        <option value="Hammer Strength" <?php if(isset($_GET['edit'])) if($editrow['fld_product_brand']=="Hammer Strength") echo "selected"; ?>>Hammer Strength</option>
        <option value="BodyCraft" <?php if(isset($_GET['edit'])) if($editrow['fld_product_brand']=="BodyCraft") echo "selected"; ?>>BodyCraft</option>
        <option value="Bowflex" <?php if(isset($_GET['edit'])) if($editrow['fld_product_brand']=="Bowflex") echo "selected"; ?>>Bowflex</option>
        <option value="Body Solid" <?php if(isset($_GET['edit'])) if($editrow['fld_product_brand']=="Body Solid") echo "selected"; ?>>Body Solid</option>
      </select> <br>
      Condition
      <input name="cond" type="radio" value="New" <?php if(isset($_GET['edit'])) if($editrow['fld_product_condition']=="New") echo "checked"; ?>> New
      <input name="cond" type="radio" value="Used" <?php if(isset($_GET['edit'])) if($editrow['fld_product_condition']=="Used") echo "checked"; ?>> Used <br>
      Manufacturing Year
      <select name="year">
        <option value="2019" <?php if(isset($_GET['edit'])) if($editrow['fld_product_year']=="2019") echo "selected"; ?>>2019</option>
        <option value="2020" <?php if(isset($_GET['edit'])) if($editrow['fld_product_year']=="2020") echo "selected"; ?>>2020</option>
        <option value="2021" <?php if(isset($_GET['edit'])) if($editrow['fld_product_year']=="2021") echo "selected"; ?>>2021</option>
        <option value="2022" <?php if(isset($_GET['edit'])) if($editrow['fld_product_year']=="2022") echo "selected"; ?>>2022</option>
        <option value="2023" <?php if(isset($_GET['edit'])) if($editrow['fld_product_year']=="2023") echo "selected"; ?>>2023</option>
        <option value="2024" <?php if(isset($_GET['edit'])) if($editrow['fld_product_year']=="2024") echo "selected"; ?>>2024</option>
        <option value="2025" <?php if(isset($_GET['edit'])) if($editrow['fld_product_year']=="2025") echo "selected"; ?>>2025</option>
      </select> <br>
      Quantity
      <input name="quantity" type="text" value="<?php if(isset($_GET['edit'])) echo $editrow['fld_product_quantity']; ?>"> <br>
      Image Filename
      <input name="image" type="text" value="<?php if(isset($_GET['edit'])) echo $editrow['fld_product_image']; ?>"> <br>
      <?php if (isset($_GET['edit'])) { ?>
      <input type="hidden" name="oldpid" value="<?php echo $editrow['fld_product_num']; ?>">
      <button type="submit" name="update">Update</button>
      <?php } else { ?>
      <button type="submit" name="create">Create</button>
      <?php } ?>
      <button type="reset">Clear</button>
    </form>
    <hr>
    <table border="1">
      <tr>
        <td>Product ID</td>
        <td>Name</td>
        <td>Price (RM)</td>
        <td>Brand</td>
        <td>Condition</td>
        <td>Year</td>
        <td>Quantity</td>
        <td></td>
      </tr>
      <?php
      // Read
      try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT * FROM tbl_products_a212509_pt2");
        $stmt->execute();
        $result = $stmt->fetchAll();
      }
      catch(PDOException $e){
            echo "Error: " . $e->getMessage();
      }
      foreach($result as $readrow) {
      ?>   
      <tr>
        <td><?php echo $readrow['fld_product_num']; ?></td>
        <td><?php echo $readrow['fld_product_name']; ?></td>
        <td><?php echo $readrow['fld_product_price']; ?></td>
        <td><?php echo $readrow['fld_product_brand']; ?></td>
        <td><?php echo $readrow['fld_product_condition']; ?></td>
        <td><?php echo $readrow['fld_product_year']; ?></td>
        <td><?php echo $readrow['fld_product_quantity']; ?></td>
        <td>
          <a href="products_details.php?pid=<?php echo $readrow['fld_product_num']; ?>">Details</a>
          <a href="products.php?edit=<?php echo $readrow['fld_product_num']; ?>">Edit</a>
          <a href="products.php?delete=<?php echo $readrow['fld_product_num']; ?>" onclick="return confirm('Are you sure to delete?');">Delete</a>
        </td>
      </tr>
      <?php
      }
      $conn = null;
      ?>
    </table>
  </center>
</body>
</html>

<?php
  include_once 'orders_details_crud.php';
?>

<!DOCTYPE html>
<html>
<head>
  <title>Fitness Machine Ordering System : Order Details</title>
</head>
<body>
  <center>
    <a href="index.php">Home</a> |
    <a href="products.php">Products</a> |
    <a href="customers.php">Customers</a> |
    <a href="staffs.php">Staffs</a> |
    <a href="orders.php">Orders</a>
    <hr>
    <?php
    // Get order info
    try {
      $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $stmt = $conn->prepare("SELECT tbl_orders_a212509.*,
        CONCAT(tbl_staffs_a212509_pt2.fld_staff_fname, ' ', tbl_staffs_a212509_pt2.fld_staff_lname) AS staff_name,
        CONCAT(tbl_customers_a212509_pt2.fld_customer_fname, ' ', tbl_customers_a212509_pt2.fld_customer_lname) AS customer_name
        FROM tbl_orders_a212509
        LEFT JOIN tbl_staffs_a212509_pt2 ON tbl_orders_a212509.fld_staff_num = tbl_staffs_a212509_pt2.fld_staff_num
        LEFT JOIN tbl_customers_a212509_pt2 ON tbl_orders_a212509.fld_customer_num = tbl_customers_a212509_pt2.fld_customer_num
        WHERE tbl_orders_a212509.fld_order_num = :oid");
      $stmt->bindParam(':oid', $oid, PDO::PARAM_STR);
      $oid = isset($_GET['oid']) ? $_GET['oid'] : '';
      $stmt->execute();
      $orderrow = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch(PDOException $e) {
      echo "Error: " . $e->getMessage();
    }
    $conn = null;
    ?>
    Order ID: <?php echo $orderrow['fld_order_num']; ?> <br>
    Order Date: <?php echo $orderrow['fld_order_date']; ?> <br>
    Staff: <?php echo $orderrow['staff_name']; ?> <br>
    Customer: <?php echo $orderrow['customer_name']; ?> <br>
    <hr>
    <form action="orders_details.php" method="post">
      <input type="hidden" name="oid" value="<?php echo isset($_GET['oid']) ? $_GET['oid'] : ''; ?>">
      Product
      <select name="pid">
        <?php
        try {
          $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
          $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
          $stmt = $conn->prepare("SELECT * FROM tbl_products_a212509_pt2");
          $stmt->execute();
          $products = $stmt->fetchAll();
        } catch(PDOException $e) {
          echo "Error: " . $e->getMessage();
        }
        foreach($products as $product) {
          echo "<option value=\"{$product['fld_product_num']}\">{$product['fld_product_name']}</option>";
        }
        $conn = null;
        ?>
      </select>
      Quantity
      <input name="quantity" type="text">
      <button type="submit" name="addproduct">Add Product</button>
      <button type="reset">Clear</button>
    </form>
    <hr>
    <table border="1">
      <tr>
        <td>Order Detail ID</td>
        <td>Product</td>
        <td>Quantity</td>
        <td></td>
      </tr>
      <?php
      try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT tbl_orders_details_a212509.*, tbl_products_a212509_pt2.fld_product_name
          FROM tbl_orders_details_a212509
          LEFT JOIN tbl_products_a212509_pt2 ON tbl_orders_details_a212509.fld_product_num = tbl_products_a212509_pt2.fld_product_num
          WHERE fld_order_num = :oid");
        $stmt->bindParam(':oid', $oid, PDO::PARAM_STR);
          $oid = isset($_GET['oid']) ? $_GET['oid'] : '';
        $stmt->execute();
        $result = $stmt->fetchAll();
      }
      catch(PDOException $e){
            echo "Error: " . $e->getMessage();
      }
      foreach($result as $detailrow) {
      ?>
      <tr>
        <td><?php echo $detailrow['fld_order_detail_num']; ?></td>
        <td><?php echo $detailrow['fld_product_name']; ?></td>
        <td><?php echo $detailrow['fld_order_detail_quantity']; ?></td>
        <td>
          <a href="orders_details.php?delete=<?php echo $detailrow['fld_order_detail_num']; ?>&oid=<?php echo $detailrow['fld_order_num']; ?>" onclick="return confirm('Are you sure to delete?');">Delete</a>
        </td>
      </tr>
      <?php
      }
      $conn = null;
      ?>
    </table>
    <hr>
    <a href="invoice.php?oid=<?php echo isset($_GET['oid']) ? $_GET['oid'] : ''; ?>" target="_blank">Generate Invoice</a>
  </center>
</body>
</html>

<?php
 
$servername = "lrgs.ftsm.ukm.my";
$username = "a212509";
$password = "largeredbird";
$dbname = "a212509";
 
?>
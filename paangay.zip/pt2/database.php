<?php
 
$servername = "lrgs.ftsm.ukm.my";
$username = "a123456";
$password = "a123456";
$dbname = "a123456";
 
?>
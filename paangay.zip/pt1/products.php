<!DOCTYPE html>
<html>
<head>
  <title>Fitness Machine Ordering System : Products</title>
</head>
<body>
  <center>
    <a href="index.php">Home</a> |
    <a href="products.php">Products</a> |
    <a href="customers.php">Customers</a> |
    <a href="staffs.php">Staffs</a> |
    <a href="orders.php">Orders</a>
    <hr>

    <form action="products.php" method="post">
      Product ID
      <input name="pid" type="text"> <br>

      Name
      <input name="name" type="text"> <br>

      Price (RM)
      <input name="price" type="text"> <br>

      Brand
      <select name="brand">
        <option value="ProFit">ProFit</option>
        <option value="PowerFit">PowerFit</option>
        <option value="FitLife">FitLife</option>
      </select> <br>

      Condition
      <input name="cond" type="radio" value="New"> New
      <input name="cond" type="radio" value="Used"> Used <br>

      Manufacturing Year
      <select name="year">
        <option value="2022">2022</option>
        <option value="2023">2023</option>
        <option value="2024">2024</option>
      </select> <br>

      Quantity
      <input name="quantity" type="text"> <br>

      <button type="submit" name="create">Create</button>
      <button type="reset">Clear</button>
    </form>

    <hr>

    <table border="1">
      <tr>
        <td>Product ID</td>
        <td>Name</td>
        <td>Price</td>
        <td>Brand</td>
        <td></td>
      </tr>

      <tr>
        <td>P001</td>
        <td>Treadmill X100</td>
        <td>1200</td>
        <td>ProFit</td>
        <td>
          <a href="products_details.php">Details</a>
          <a href="products.php">Edit</a>
          <a href="products.php">Delete</a>
        </td>
      </tr>

      <tr>
        <td>P002</td>
        <td>Dumbbell Set 20kg</td>
        <td>150</td>
        <td>PowerFit</td>
        <td>
          <a href="products_details.php">Details</a>
          <a href="products.php">Edit</a>
          <a href="products.php">Delete</a>
        </td>
      </tr>

    </table>
  </center>
</body>
</html>